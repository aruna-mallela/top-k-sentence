# topksentences
Python project to find top k sentences in a text document
python.py is the main file 
file.txt is main file to be sorted out
cleared.txt is file.txt with no clutter or unuseful words
tokenised.txt is file with ranks
